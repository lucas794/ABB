#ifndef PRUEBAS_ALUMNOS
#define PRUEBAS_ALUMNOS

void prueba_abb_vacio(void);

void prueba_abb_guardar_borrar(void);
void prueba_iterador(void);
void pruebas_abb_alumno(void);
#endif
